package com.example.poojapatel.galleryart;

import android.os.Bundle;
import android.app.Activity;

public class Main4Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

}
